const o="/icons/office.svg";export{o as _};
