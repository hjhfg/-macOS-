import{bG as a}from"./appBootstrap-Ef1yS5Ey.js";async function o(o=!1){return a(o)}export{o as a};
