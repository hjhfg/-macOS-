#!/usr/bin/env python3
"""Serve the exported TabOS frontend with the small API surface it needs locally.

The export is otherwise static, so this keeps the normal SimpleHTTPRequestHandler
behavior and only handles the weather POST that a static server cannot accept.
"""

from __future__ import annotations

import argparse
import json
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse


WEATHER_DATA = {
    "city": "北京",
    "weather": {
        "temperature": 20,
        "weather": "晴",
        "real_feel_temperature": 20,
        "wind_direction": "北风",
        "wind_power": "1级",
        "temperature_night": 15,
        "temperature_day": 24,
    },
    "ps_pm25": {"ps_pm25": 0, "level": ""},
    "long_day_forecast": {
        "info": [
            {
                "date": "2026-08-17",
                "weather_day": "晴",
                "weather_night": "晴",
                "temperature_day": 24,
                "temperature_night": 15,
                "precipitation_probability_day": "0",
            }
        ]
    },
    "alarm": [],
    "24_hour_forecast": {"info": []},
}


class ExportHandler(SimpleHTTPRequestHandler):
    """Static export handler plus deterministic local weather responses."""

    def _send_json(self, payload: object, status: int = 200) -> None:
        encoded = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def do_GET(self) -> None:  # noqa: N802 - stdlib handler API
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/")
        if path == "/api/v1/weather/locations":
            self._send_json({"locations": []})
            return
        if path == "/api/v1/weather/reverse":
            self._send_json(
                {
                    "location": {
                        "id": "beijing",
                        "name": "北京",
                        "displayName": "北京市",
                        "latitude": 39.9042,
                        "longitude": 116.4074,
                        "category": "city",
                        "type": "city",
                        "address": {"city": "北京市", "province": "北京市"},
                    }
                }
            )
            return
        # A static export cannot establish the realtime WebSocket, but returning
        # a valid JSON response avoids an endless 404 retry loop in guest mode.
        if path == "/api/v1/im/ws/guest":
            self._send_json({"code": 0, "data": None, "message": "realtime unavailable"})
            return
        super().do_GET()

    def do_POST(self) -> None:  # noqa: N802 - stdlib handler API
        path = urlparse(self.path).path.rstrip("/")
        if path == "/api/v1/weather":
            length = int(self.headers.get("Content-Length", "0"))
            if length:
                self.rfile.read(length)
            self._send_json({"query": "北京", "data": WEATHER_DATA})
            return
        self._send_json({"code": 0, "data": None}, status=404)

    def do_OPTIONS(self) -> None:  # noqa: N802 - stdlib handler API
        self.send_response(204)
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type,Authorization")
        self.end_headers()


def main() -> None:
    parser = argparse.ArgumentParser(description="Serve the local TabOS static export")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    server = ThreadingHTTPServer(("", args.port), ExportHandler)
    print(f"Serving TabOS export at http://127.0.0.1:{args.port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
