const SYSTEM_EMOJI_CACHE_PREFIX = 'tabos-system-emoji-assets-'
const SYSTEM_EMOJI_CACHE_NAME = `${SYSTEM_EMOJI_CACHE_PREFIX}v3`
const SYSTEM_EMOJI_ASSET_PATH = '/api/v1/message-emoji-assets/'

self.addEventListener('install', (event) => {
  event.waitUntil(self.skipWaiting())
})

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const cacheNames = await caches.keys()
    await Promise.all(
      cacheNames
        .filter(name => name.startsWith(SYSTEM_EMOJI_CACHE_PREFIX) && name !== SYSTEM_EMOJI_CACHE_NAME)
        .map(name => caches.delete(name)),
    )
    await self.clients.claim()
  })())
})

self.addEventListener('fetch', (event) => {
  const request = event.request
  if (request.method !== 'GET') return

  const url = new URL(request.url)
  if (url.origin !== self.location.origin || !url.pathname.startsWith(SYSTEM_EMOJI_ASSET_PATH)) return

  event.respondWith((async () => {
    const cache = await caches.open(SYSTEM_EMOJI_CACHE_NAME)
    const cachedResponse = await cache.match(request, { ignoreVary: true })
    if (cachedResponse) return cachedResponse

    const networkResponse = await fetch(request)
    if (networkResponse.ok && networkResponse.status === 200) {
      await cache.put(request, networkResponse.clone())
    }
    return networkResponse
  })())
})
