<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="UTF-8">
    <link rel="icon" href="/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="referrer" content="no-referrer">
    <title>Tabos 系统</title>
    <script>
      // 立即应用保存的主题，避免首次加载闪烁；未保存时先用后台默认兜底 dark，随后由站点设置校正
      (function() {
        var theme = localStorage.getItem('theme');
        var initialTheme = theme === 'light' || theme === 'dark' ? theme : 'dark';
        document.documentElement.setAttribute('data-theme', initialTheme);
        if (initialTheme === 'dark') {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      })();
    </script>
    <script type="module" crossorigin src="/assets/main-Ds3zb1rO.js"></script>
    <link rel="modulepreload" crossorigin href="/assets/vendor-vue-qPbIny6K.js">
    <link rel="modulepreload" crossorigin href="/assets/vendor-calendar-utils-CKImCfXa.js">
    <link rel="modulepreload" crossorigin href="/assets/vendor-common-BtWKOo0i.js">
    <link rel="modulepreload" crossorigin href="/assets/vendor-codemirror-D6N1lkUf.js">
    <link rel="modulepreload" crossorigin href="/assets/bootstrapLocale-DvxOZIcg.js">
    <link rel="stylesheet" crossorigin href="/assets/vendor-common-DkXflFTP.css">
  </head>
  <body>
    <div id="app">
      <!-- 预加载占位：Vue 挂载后自动替换 -->
      <div id="app-loading" style="position:fixed;inset:0;background:#000;display:flex;align-items:center;justify-content:center;z-index:9999">
        <div id="app-loading-title" style="font-size:42px;font-weight:700;letter-spacing:6px;color:#fff;opacity:0;animation:app-title-in 1.2s ease-out forwards;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif"></div>
      </div>
      <style>@keyframes app-title-in{0%{opacity:0;transform:translateY(12px) scale(.96);filter:blur(8px)}100%{opacity:.9;transform:translateY(0) scale(1);filter:blur(0)}}</style>
      <script>
        (function(){
          var el = document.getElementById('app-loading-title');
          var apiBase = '' || '';

          function isLocalOrPrivateHost(hostname){
            var host = String(hostname || '').toLowerCase();
            if(host === 'localhost' || host === '127.0.0.1' || host === '::1') return true;
            var match = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host);
            if(!match) return false;
            var first = Number(match[1]);
            var second = Number(match[2]);
            return first === 10 || (first === 172 && second >= 16 && second <= 31) || (first === 192 && second === 168);
          }

          function redirectToCanonicalHTTPS(siteUrl){
            if(window.location.protocol !== 'http:' || !siteUrl) return false;
            try {
              var canonical = new URL(siteUrl);
              if(canonical.protocol !== 'https:' || canonical.host !== window.location.host || isLocalOrPrivateHost(canonical.hostname)) return false;
              var target = new URL(window.location.href);
              target.protocol = 'https:';
              window.location.replace(target.toString());
              return true;
            } catch(_) {
              return false;
            }
          }

          window.__redirectingToCanonicalHTTPS = false;
          var p = fetch(apiBase + '/api/v1/settings/site')
            .then(function(r){ return r.json(); })
            .then(function(json){
              if(json.code === 0 && json.data){
                if(redirectToCanonicalHTTPS(json.data.siteUrl)){
                  window.__redirectingToCanonicalHTTPS = true;
                  return null;
                }
                if(json.data.siteName){
                  el.textContent = json.data.siteName;
                  document.title = json.data.siteName;
                }
                var savedTheme = localStorage.getItem('theme');
                if(savedTheme !== 'light' && savedTheme !== 'dark'){
                  var defaultTheme = json.data.defaultThemeMode === 'light' ? 'light' : 'dark';
                  document.documentElement.setAttribute('data-theme', defaultTheme);
                  document.documentElement.classList.toggle('dark', defaultTheme === 'dark');
                }
                return json.data;
              }
              return null;
            })
            .catch(function(){ return null; });
          // 缓存请求 Promise，供 Vue 应用复用，避免重复请求。
          window.__siteSettingsPromise = p;
        })();
      </script>
    </div>
  </body>
</html>
